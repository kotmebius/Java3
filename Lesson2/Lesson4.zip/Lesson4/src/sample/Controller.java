package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class Controller {
    @FXML
    TextArea mainTextArea;
    @FXML
    TextField inputText;
    @FXML
    Button sendMsgButton;
    @FXML
    VBox body = new VBox();
    @FXML
    MenuBar menu = new MenuBar();
    @FXML
    Menu fontMenu = new Menu();
    @FXML
    MenuItem fontMinus2 = new MenuItem();
    @FXML
    MenuItem fontMinus1 = new MenuItem();
    @FXML
    MenuItem fontNormal = new MenuItem();
    @FXML
    MenuItem fontPlus1 = new MenuItem();
    @FXML
    MenuItem fontPlus2 = new MenuItem();
    @FXML
    ToggleGroup $themeToggle = new ToggleGroup();


    public void sendMsg(ActionEvent actionEvent) {
        mainTextArea.appendText(inputText.getText() + "\n");
        inputText.setText("");
        inputText.requestFocus();
    }

    public void setFontMinus2(ActionEvent actionEvent) {
        body.setStyle("-fx-font-size: 12px;");
        inputText.requestFocus();
    }
    public void setFontMinus1(ActionEvent actionEvent) {
        body.setStyle("-fx-font-size: 14px;");
        inputText.requestFocus();
    }
    public void setFontNormal(ActionEvent actionEvent) {
        body.setStyle("-fx-font-size: 16px;");
        inputText.requestFocus();
    }
    public void setFontPlus1(ActionEvent actionEvent) {
        body.setStyle("-fx-font-size: 18px;");
        inputText.requestFocus();
    }
    public void setFontPlus2(ActionEvent actionEvent) {
        body.setStyle("-fx-font-size: 20px;");
        inputText.requestFocus();
    }

    public void setLightTheme (ActionEvent actionEvent){
        System.out.println(menu.getStyleClass());
        System.out.println(body.getStyleClass());
        mainTextArea.getStyleClass().set(2, "lightTextArea");
        inputText.getStyleClass().set(2, "lightInputText");
        sendMsgButton.getStyleClass().set(1, "lightButton");
        menu.getStyleClass().set(1, "lightMenu");
        body.getStyleClass().set(1, "lightBody");
        inputText.requestFocus();
    }
    public void setDarkTheme (ActionEvent actionEvent){
        System.out.println(menu.getStyleClass());
        System.out.println(body.getStyleClass());
        mainTextArea.getStyleClass().set(2, "darkTextArea");
        inputText.getStyleClass().set(2, "darkInputText");
        sendMsgButton.getStyleClass().set(1, "darkButton");
        menu.getStyleClass().set(1, "darkMenu");
        body.getStyleClass().set(1, "darkBody");
        inputText.requestFocus();
    }
    public void setBrightTheme (ActionEvent actionEvent){
        System.out.println(menu.getStyleClass());
        System.out.println(body.getStyleClass());
        mainTextArea.getStyleClass().set(2, "brightTextArea");
        inputText.getStyleClass().set(2, "brightInputText");
        sendMsgButton.getStyleClass().set(1, "brightButton");
        menu.getStyleClass().set(1, "brightMenu");
        body.getStyleClass().set(1, "brightBody");
        inputText.requestFocus();
    }

}

